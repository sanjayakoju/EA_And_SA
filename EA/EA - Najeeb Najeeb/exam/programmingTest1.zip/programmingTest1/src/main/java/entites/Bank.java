package entites;

import javax.persistence.*;

@Entity
@DiscriminatorValue("Bank")
public class Bank extends Owner {

    @Id
    @GeneratedValue
    private Long id;

    @OneToOne(cascade = CascadeType.PERSIST)
    private Address bankAddress;

    public Bank() {
    }

    public Address getBankAddress() {
        return bankAddress;
    }

    public void setBankAddress(Address bankAddress) {
        this.bankAddress = bankAddress;
    }
}
