import entites.*;

import javax.persistence.*;
import javax.persistence.criteria.*;
import java.sql.SQLOutput;
import java.util.List;

public class Main {

    private static EntityManagerFactory emf;
    private static EntityManager em;

    public static void main(String[] args) {
        System.out.println("Start App");

        setup();

        populateDatabase();

        getAllHouseInMarket();

        getAllHouseInMarketWithCriteria();

        getAllOwnerWithSellingHouse();

        close();

        System.out.println("End App");
    }

    private static void populateDatabase() {
        EntityTransaction tx= em.getTransaction();
        tx.begin();

        Address fairfieldRealEstateAddress= new Address("52 E. Burlington", "Fairfield", "IA", "52556");
        Realtor fairfieldRealEstate= new Realtor("Fairfield Real Estate, Inc.", 12, fairfieldRealEstateAddress);
        Address burlingtonHouseAddress= new Address("501 E Burlington Avenue", "Fairfield", "IA", "52556");
        House burlingtonHouse= new House(157500, burlingtonHouseAddress);
        fairfieldRealEstate.addHouse(burlingtonHouse);
        Address suncrestHouseAddress= new Address("904 S Suncrest Drive", "Fairfield", "IA", "52556");
        House suncrestHouse= new House(465000, suncrestHouseAddress);
        fairfieldRealEstate.addHouse(suncrestHouse);
        Address hempsteadHouseAddress= new Address("105 W Hempstead Ave", "Fairfield", "IA", "52556");
        House hempsteadHouse= new House(134000, hempsteadHouseAddress);
        fairfieldRealEstate.soldHouse(hempsteadHouse);

        Address villageRealtyAddress= new Address("60 N. Main St.", "Fairfield", "IA", "52556");
        Realtor villageRealty= new Realtor("Village Realty", 8, villageRealtyAddress);
        Address briggsHouseAddress= new Address("705 W Briggs Avenue", "Fairfield", "IA", "52556");
        House briggsHouse= new House(110000, briggsHouseAddress);
        villageRealty.addHouse(briggsHouse);
        Address lakeviewHouseAddress= new Address("1105 Lakeview Drive", "Fairfield", "IA", "52556");
        House lakeviewHouse= new House(1500000, lakeviewHouseAddress);
        villageRealty.addHouse(lakeviewHouse);
        Address silverlakeHouseAddress= new Address("402 Silverlakes Dr.", "Fairfield", "IA", "52556");
        House silverlakeHouse= new House(569000, silverlakeHouseAddress);
        villageRealty.soldHouse(silverlakeHouse);

        Person person1 = new Person();
        person1.setName("Jack");
        person1.setAge(32);

        briggsHouse.setOwnerName(person1);

        Person person2 = new Person();
        person2.setAge(28);
        person2.setName("Jill");
        briggsHouse.setOwnerName(person2);

        Bank bank1 = new Bank();
        bank1.setName("MidwestOne");
        bank1.setBankAddress(new Address("58 E Burrlinton Ave", "Fairfield", "IA", "52556"));
        suncrestHouse.setOwnerName(bank1);

        Bank bank2 = new Bank();
        bank2.setName("USBank");
        bank2.setBankAddress(new Address("301 E Washington St", "Mount Pleasant", "IA", "52641"));
        lakeviewHouse.setOwnerName(bank2);

        Person person3 = new Person();
        person3.setName("Jim");
        person3.setAge(40);
        hempsteadHouse.setOwnerName(person3);

        Person person4 = new Person();
        person4.setAge(40);
        person4.setName("Jasmin");
        silverlakeHouse.setOwnerName(person4);


        em.persist(fairfieldRealEstate);
        em.persist(villageRealty);

        tx.commit();
    }

    private static void close() {
        em.close();
        emf.close();
    }

    private static void setup() {
        emf= Persistence.createEntityManagerFactory("CS544DB_PU");
        em= emf.createEntityManager();
    }


    public static void getAllHouseInMarket() {
        System.out.println("Query 1 Results");
        String stringSql = "SELECT DISTINCT h FROM House h JOIN Realtor r WHERE  r.employeeCount > 10";
        Query query = em.createQuery(stringSql, House.class);
        List<House> houseList = query.getResultList();
        System.out.println(houseList);

    }

    public static void getAllHouseInMarketWithCriteria() {
        System.out.println("Query 2 Results");
        CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery criteriaQuery = criteriaBuilder.createQuery();
        Root<Realtor> realtorRoot = criteriaQuery.from(Realtor.class);

        Join<Realtor, House> joinHouse = realtorRoot.join("housesForSale");
        Join<House, Address> joinAddress = joinHouse.join("location");

        Predicate cityPredicate = criteriaBuilder.equal(joinAddress.get("state"), "IA");
        Predicate employeesPredicate = criteriaBuilder.lessThan(realtorRoot.get("employeeCount"), 8);
        Predicate costPredicate = criteriaBuilder.greaterThan(joinHouse.get("price"), 500000);

        Predicate finalPredicate = criteriaBuilder.and(cityPredicate, employeesPredicate, costPredicate);

        criteriaQuery.where(finalPredicate);

        Query query = em.createQuery(criteriaQuery);

        List<Realtor> realtorList = query.getResultList();

        System.out.println(realtorList);

    }

    public static void getAllOwnerWithSellingHouse(){
        System.out.println("Query 3 Results");
        String sqlString = "SELECT * from owner as o JOIN house as h on o.id = h.OWNERNAME_ID where h.price > 120000";
        Query query = em.createNativeQuery(sqlString, Owner.class);
        List<Owner> ownerList = query.getResultList();
        System.out.println(ownerList);
    }

}
