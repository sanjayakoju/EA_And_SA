package entites;

import javax.persistence.*;

@Entity
public class House {

    @Id @GeneratedValue
    private int id;
    private int price;
    @OneToOne(cascade = CascadeType.PERSIST)
    private Address location;

    @OneToOne(cascade = CascadeType.PERSIST)
    private Owner ownerName;

    public House() {
    }

    public House(int price, Address location) {
        this.price = price;
        this.location = location;
    }

    public void setOwnerName(Owner ownerName) {
        this.ownerName = ownerName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Address getLocation() {
        return location;
    }

    public void setLocation(Address location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "House{" +
                "id=" + id +
                ", price=" + price +
                ", location=" + location +
                '}';
    }
}
