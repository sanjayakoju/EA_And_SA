package entites;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Realtor {

    @Id @GeneratedValue
    private int id;
    private String name;
    private int employeeCount;
    @OneToOne(cascade = CascadeType.PERSIST)
    private Address location;
    @OneToMany(cascade = CascadeType.PERSIST)
    @JoinTable(name = "SoldHouses")
    private List<House> housesSold= new ArrayList<>();
    @OneToMany(cascade = CascadeType.PERSIST)
    @JoinTable(name = "ListHouses")
    private List<House> housesForSale= new ArrayList<>();

    public Realtor() {
    }

    public Realtor(String name, int employeeCount, Address location) {
        this.name = name;
        this.employeeCount = employeeCount;
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEmployeeCount() {
        return employeeCount;
    }

    public void setEmployeeCount(int employeeCount) {
        this.employeeCount = employeeCount;
    }

    public Address getLocation() {
        return location;
    }

    public void setLocation(Address location) {
        this.location = location;
    }

    public List<House> getHousesSold() {
        return housesSold;
    }

    public void setHousesSold(List<House> housesSold) {
        this.housesSold = housesSold;
    }

    public List<House> getHousesForSale() {
        return housesForSale;
    }

    public void setHousesForSale(List<House> housesForSale) {
        this.housesForSale = housesForSale;
    }

    public void addHouse(House house) {
        this.housesForSale.add(house);
    }

    public void soldHouse(House house) {
        this.housesSold.add(house);
    }

    @Override
    public String toString() {
        return "Realtor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", employeeCount=" + employeeCount +
                ", location=" + location +
                ", housesSold=" + housesSold +
                ", housesForSale=" + housesForSale +
                '}';
    }
}
