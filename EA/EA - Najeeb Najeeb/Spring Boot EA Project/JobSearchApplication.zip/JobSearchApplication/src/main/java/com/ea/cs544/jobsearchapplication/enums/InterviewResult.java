package com.ea.cs544.jobsearchapplication.enums;

public enum InterviewResult {

        PASS,FAIL
}
