package com.ea.cs544.jobsearchapplication.enums;

public enum Location {

    PHONE,ONLINE,IN_PERSON
}
