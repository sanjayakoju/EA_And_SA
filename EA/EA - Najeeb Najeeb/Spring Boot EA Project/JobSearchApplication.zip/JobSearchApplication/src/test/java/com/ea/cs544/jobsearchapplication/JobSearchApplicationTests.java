package com.ea.cs544.jobsearchapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobSearchApplicationTests {

    @Test
    void contextLoads() {
    }

}
