package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.Job;
import com.eaproject.jsearch.entities.JobApplication;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.JobApplicationRepository;
import com.eaproject.jsearch.service.core.JobApplicationServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class JobApplicationServiceTest {

    @Mock
    private JobApplicationRepository jobApplicationRepository;

    @InjectMocks
    private JobApplicationServiceImpl jobApplicationServiceImpl;

    private JobApplication newJobApplication;

    @BeforeEach
    public void beforeEach() {
        newJobApplication = createNewJobApplication1();
    }

    private JobApplication createNewJobApplication1() {
        JobApplication softEngApplication = new JobApplication();
        softEngApplication.setAppliedDateTime(LocalDateTime.now());
        softEngApplication.setJob(new Job());
        return softEngApplication;
    }

    private JobApplication createSavedJobApplication2() {
        JobApplication fullStackApplication = new JobApplication();
        fullStackApplication.setId(1L);
        fullStackApplication.setAppliedDateTime(LocalDateTime.now().minusDays(10));
        fullStackApplication.setJob(new Job());
        return fullStackApplication;
    }

    @Test
    public void testGetAllJobApplications() {

        List<JobApplication> repositoryJobApplicationList = List.of(createSavedJobApplication2());
        when(jobApplicationRepository.findAll()).thenReturn(repositoryJobApplicationList);
        Assertions.assertEquals(jobApplicationServiceImpl.getAllJobApplications(), repositoryJobApplicationList);
    }

    @Test
    public void testGetByJobApplicationID() {

        when(jobApplicationRepository.findById(newJobApplication.getId())).thenReturn(Optional.ofNullable(newJobApplication));
        Assertions.assertEquals(jobApplicationServiceImpl.getJobApplicationById(newJobApplication.getId()), newJobApplication);
    }

    @Test
    public void testExpectedException_whenGetByJobApplicationIdIsNullOrJobApplicationNotAvailable() {

        JobApplication savedJobApplication = createSavedJobApplication2(); // Id 1L
        lenient().when(jobApplicationRepository.findById(savedJobApplication.getId())).thenReturn(Optional.ofNullable(savedJobApplication));

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            jobApplicationServiceImpl.getJobApplicationById(null);
        });

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            jobApplicationServiceImpl.getJobApplicationById(2L);
        });
    }

    @Test
    public void testSaveNewJobApplication() {

        when(jobApplicationRepository.save(newJobApplication)).thenReturn(newJobApplication);
        Assertions.assertEquals(jobApplicationServiceImpl.save(newJobApplication), newJobApplication);
    }

    @Test
    public void testUpdateJobApplication() {

        JobApplication savedJobApplication = createSavedJobApplication2();
        when(jobApplicationRepository.findById(savedJobApplication.getId())).thenReturn(Optional.ofNullable(savedJobApplication));
        when(jobApplicationRepository.save(savedJobApplication)).thenReturn(savedJobApplication);
        Assertions.assertEquals(jobApplicationServiceImpl.updateJobApplication(savedJobApplication), savedJobApplication);
    }

    @Test
    public void testDeleteJobApplication() {

        JobApplication savedJobApplication = createSavedJobApplication2();
        when(jobApplicationRepository.findById(savedJobApplication.getId())).thenReturn(Optional.ofNullable(savedJobApplication));
        doNothing().when(jobApplicationRepository).deleteById(savedJobApplication.getId());
        Assertions.assertTrue(jobApplicationServiceImpl.deleteJobApplication(1L));
    }


}
