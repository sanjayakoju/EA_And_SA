package com.eaproject.jsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JSearchEaProjectJobJobApplicationTestsRepository {

    @Test
    void contextLoads() {
    }

}
