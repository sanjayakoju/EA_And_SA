package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.Address;
import com.eaproject.jsearch.entities.Job;
import com.eaproject.jsearch.entities.Skill;
import com.eaproject.jsearch.entities.company.Branch;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.company.Recruiter;
import com.eaproject.jsearch.entities.enums.PositionLevel;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.JobRepository;
import com.eaproject.jsearch.service.core.JobServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class JobServiceTest {

    @Mock
    private JobRepository jobRepository;

    @InjectMocks
    private JobServiceImpl jobServiceImpl;

    private Job newJob;

    @BeforeEach
    public void beforeEach() {
        newJob = createNewJob1();
    }

    private Job createNewJob1() {
        Job srSEngineer = new Job();
        srSEngineer.setTitle("Senior Software Engineer");
        srSEngineer.setFullDescription("Fully remote Senior Software Engineer to join their team");
        srSEngineer.setRemote(true);
        srSEngineer.setMinRequiredExpInYears(4.0);
        srSEngineer.setPositionLevel(PositionLevel.SENIOR);
        srSEngineer.setSalaryEstimateKPerYear(120);
        srSEngineer.setSelfRatingPercent(100);
        Company companyKForce = new Recruiter();
        srSEngineer.setCompany(companyKForce);
        Branch kForceGABranch = new Branch(companyKForce, new Address("Georgia State", "Atlanta", 0), 0);
        srSEngineer.setBranch(kForceGABranch);
        srSEngineer.setSkills(List.of(
                new Skill("Frontend", 2.0, "", "JavaScript, Angular", srSEngineer),
                new Skill("Backend", 2.0, "", "Java, Spring", srSEngineer),
                new Skill("Knowledge", 2.0, "", "MySQL, Docker, AWS, GIT", srSEngineer),
                new Skill("Preferred", 4.0, "", "ELK Stack, Mongo DB, Postgres, Graph QL", srSEngineer)
        ));
        return srSEngineer;
    }

    private Job createSavedJob2() {
        Job fullStackDeveloper = new Job();
        fullStackDeveloper.setId(1L);
        fullStackDeveloper.setTitle("Full Stack Developer");
        fullStackDeveloper.setFullDescription("Full stack REST Api, Spring, Angular or React Developer");
        fullStackDeveloper.setRemote(false);
        fullStackDeveloper.setMinRequiredExpInYears(1);
        fullStackDeveloper.setPositionLevel(PositionLevel.MID);
        fullStackDeveloper.setSalaryEstimateKPerYear(100);
        fullStackDeveloper.setSelfRatingPercent(90);
        Company companyKForce = new Recruiter();
        fullStackDeveloper.setCompany(companyKForce);

        Branch kForceFLBranch = new Branch(companyKForce, new Address("Florida", "Miramar", 0), 0);
        fullStackDeveloper.setBranch(kForceFLBranch);
        fullStackDeveloper.setSkills(List.of(
                new Skill("FullStack", 1.0, "", "Node/Spring/C++, JavaScript", fullStackDeveloper),
                new Skill("Preferred", 4.0, "", "REST Api, Web Development, GIT, Database", fullStackDeveloper)
        ));
        return fullStackDeveloper;
    }

    @Test
    public void testGetAllJobs() {

        List<Job> repositoryJobList = List.of(createSavedJob2());
        when(jobRepository.findAll()).thenReturn(repositoryJobList);
        Assertions.assertEquals(jobServiceImpl.getAllJobs(), repositoryJobList);
    }

    @Test
    public void testGetByJobID() {

        when(jobRepository.findById(newJob.getId())).thenReturn(Optional.ofNullable(newJob));
        Assertions.assertEquals(jobServiceImpl.getJobById(newJob.getId()), newJob);
    }

    @Test
    public void testExpectedException_whenGetByJobIdIsNullOrJobNotAvailable() {

        Job savedJob = createSavedJob2(); // Id 1L
        lenient().when(jobRepository.findById(savedJob.getId())).thenReturn(Optional.ofNullable(savedJob));

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            jobServiceImpl.getJobById(null);
        });

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            jobServiceImpl.getJobById(2L);
        });
    }

    @Test
    public void testSaveNewJob() {

        when(jobRepository.save(newJob)).thenReturn(newJob);
        Assertions.assertEquals(jobServiceImpl.save(newJob), newJob);
    }

    @Test
    public void testUpdateJob() {

        Job savedJob = createSavedJob2();
        when(jobRepository.findById(savedJob.getId())).thenReturn(Optional.ofNullable(savedJob));
        when(jobRepository.save(savedJob)).thenReturn(savedJob);
        Assertions.assertEquals(jobServiceImpl.updateJob(savedJob), savedJob);
    }

    @Test
    public void testDeleteJob() {

        Job savedJob = createSavedJob2();
        when(jobRepository.findById(savedJob.getId())).thenReturn(Optional.ofNullable(savedJob));
        doNothing().when(jobRepository).deleteById(savedJob.getId());
        Assertions.assertTrue(jobServiceImpl.deleteJobApplication(1L));
    }


}
