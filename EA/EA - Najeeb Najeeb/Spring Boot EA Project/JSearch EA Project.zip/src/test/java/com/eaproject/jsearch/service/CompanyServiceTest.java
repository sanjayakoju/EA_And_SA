package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.Address;
import com.eaproject.jsearch.entities.company.Branch;
import com.eaproject.jsearch.entities.company.Client;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.company.Recruiter;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.CompanyRepository;
import com.eaproject.jsearch.service.core.CompanyServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CompanyServiceTest {

    @Mock
    private CompanyRepository companyRepository;

    @InjectMocks
    private CompanyServiceImpl companyServiceImpl;

    private Company newCompany;

    @BeforeEach
    public void beforeEach() {
        newCompany = createNewClientCompany1();
    }

    private Client createNewClientCompany1() {
        // Clients
        Client google = new Client();
        google.setName("Google");
        google.setDescription("Google");
        Branch googleCABranch = new Branch(google, new Address("California", "Mountain View", 0), 0);
        google.setMainBranch(googleCABranch);
        return google;
    }

    private Recruiter createSavedRecruiterCompany2() {
        Recruiter kForce = new Recruiter();
        kForce.setId(1L);
        kForce.setName("KForce");
        kForce.setHasPrevAlumni(true);
        Branch kForceFLBranch = new Branch(kForce, new Address("Florida", "Tampa", 0), 0);
        kForce.setMainBranch(kForceFLBranch);
//        kForce.setClients(List.of(google, microsoft));
        return kForce;
    }

    @Test
    public void testGetAllCompanies() {

        List<Company> repositoryCompanyList = List.of(createSavedRecruiterCompany2());
        when(companyRepository.findAll()).thenReturn(repositoryCompanyList);
        Assertions.assertEquals(companyServiceImpl.getAllCompanies(), repositoryCompanyList);
    }

    @Test
    public void testGetByCompanyID() {

        when(companyRepository.findById(newCompany.getId())).thenReturn(Optional.ofNullable(newCompany));
        Assertions.assertEquals(companyServiceImpl.getById(newCompany.getId()), newCompany);
    }

    @Test
    public void testExpectedException_whenGetByCompanyIdIsNullOrCompanyNotAvailable() {

        Company savedCompany = createSavedRecruiterCompany2(); // Id 1L
        lenient().when(companyRepository.findById(savedCompany.getId())).thenReturn(Optional.ofNullable(savedCompany));

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            companyServiceImpl.getById(null);
        });

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            companyServiceImpl.getById(2L);
        });
    }

    @Test
    public void testSaveNewCompany() {

        when(companyRepository.save(newCompany)).thenReturn(newCompany);
        Assertions.assertEquals(companyServiceImpl.save(newCompany), newCompany);
    }

    @Test
    public void testUpdateRecruiterCompany() {

        Recruiter savedRecruiterCompany = createSavedRecruiterCompany2();
        when(companyRepository.getRecruiterById(savedRecruiterCompany.getId())).thenReturn(Optional.ofNullable(savedRecruiterCompany));
        when(companyRepository.save(savedRecruiterCompany)).thenReturn(savedRecruiterCompany);
        Assertions.assertEquals(companyServiceImpl.updateRecruiter(savedRecruiterCompany), savedRecruiterCompany);
    }

    @Test
    public void testDeleteCompany() {

        Recruiter savedRecruiterCompany = createSavedRecruiterCompany2();
        when(companyRepository.findById(savedRecruiterCompany.getId())).thenReturn(Optional.ofNullable(savedRecruiterCompany));
        doNothing().when(companyRepository).deleteById(savedRecruiterCompany.getId());
        Assertions.assertTrue(companyServiceImpl.deleteCompany(1L));
    }

}
