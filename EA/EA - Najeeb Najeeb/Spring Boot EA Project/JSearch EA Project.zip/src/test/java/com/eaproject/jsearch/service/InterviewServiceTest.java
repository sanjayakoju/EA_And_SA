package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.Interview;
import com.eaproject.jsearch.entities.JobApplication;
import com.eaproject.jsearch.entities.enums.InterviewType;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.InterviewRepository;
import com.eaproject.jsearch.service.core.InterviewServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class InterviewServiceTest {

    @Mock
    private InterviewRepository interviewRepository;

    @InjectMocks
    private InterviewServiceImpl interviewServiceImpl;

    private Interview newInterview;

    @BeforeEach
    public void beforeEach() {
        newInterview = createNewInterview1();
    }

    private Interview createNewInterview1() {
        Interview technicalInterview = new Interview();
        technicalInterview.setInterviewType(InterviewType.TECHNICAL_INTERVIEW);
        technicalInterview.setJobApplication(new JobApplication());
        technicalInterview.setInterviewDateTime(LocalDateTime.now().minusDays(1));
        technicalInterview.setDurationHours(1.5);
        technicalInterview.setOverallSummary("Was asked about Java, Spring, Hibernate, Testing, Microservices, SQL and some JavaScript");
        technicalInterview.setSuccessProbabilityPercent(70);
        return technicalInterview;
    }

    private Interview createSavedInterview2() {
        Interview screeningInterview = new Interview();
        screeningInterview.setId(1L);
        screeningInterview.setInterviewType(InterviewType.SCREENING_INTERVIEW);
        screeningInterview.setJobApplication(new JobApplication());
        screeningInterview.setInterviewDateTime(LocalDateTime.now().minusDays(5));
        screeningInterview.setDurationHours(0.5);
        screeningInterview.setOverallSummary("Worked on algorithm and programming question");
        screeningInterview.setSuccessProbabilityPercent(90);
        screeningInterview.setPassed(true);
        return screeningInterview;
    }

    @Test
    public void testGetAllInterviews() {

        List<Interview> repositoryInterviewList = List.of(createSavedInterview2());
        when(interviewRepository.findAll()).thenReturn(repositoryInterviewList);
        Assertions.assertEquals(interviewServiceImpl.getAllInterviews(), repositoryInterviewList);
    }

    @Test
    public void testGetByInterviewID() {

        when(interviewRepository.findById(newInterview.getId())).thenReturn(Optional.ofNullable(newInterview));
        Assertions.assertEquals(interviewServiceImpl.getInterviewById(newInterview.getId()), newInterview);
    }

    @Test
    public void testExpectedException_whenGetByInterviewIdIsNullOrInterviewNotAvailable() {

        Interview savedInterview = createSavedInterview2(); // Id 1L
        lenient().when(interviewRepository.findById(savedInterview.getId())).thenReturn(Optional.ofNullable(savedInterview));

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            interviewServiceImpl.getInterviewById(null);
        });

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            interviewServiceImpl.getInterviewById(2L);
        });
    }

    @Test
    public void testSaveNewInterview() {

        when(interviewRepository.save(newInterview)).thenReturn(newInterview);
        Assertions.assertEquals(interviewServiceImpl.save(newInterview), newInterview);
    }

    @Test
    public void testUpdateInterview() {

        Interview savedInterview = createSavedInterview2();
        when(interviewRepository.findById(savedInterview.getId())).thenReturn(Optional.ofNullable(savedInterview));
        when(interviewRepository.save(savedInterview)).thenReturn(savedInterview);
        Assertions.assertEquals(interviewServiceImpl.updateInterview(savedInterview), savedInterview);
    }

    @Test
    public void testDeleteInterview() {

        Interview savedInterview = createSavedInterview2();
        when(interviewRepository.findById(savedInterview.getId())).thenReturn(Optional.ofNullable(savedInterview));
        doNothing().when(interviewRepository).deleteById(savedInterview.getId());
        Assertions.assertTrue(interviewServiceImpl.deleteInterview(1L));
    }

}
