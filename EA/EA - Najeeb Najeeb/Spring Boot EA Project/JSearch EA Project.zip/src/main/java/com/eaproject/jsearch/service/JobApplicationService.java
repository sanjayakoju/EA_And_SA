package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.JobApplication;

import java.util.List;

public interface JobApplicationService {

    List<JobApplication> getAllJobApplications();

    JobApplication getJobApplicationById(Long id);

    JobApplication save(JobApplication jobApplication);

    JobApplication updateJobApplication(JobApplication jobApplication);

    boolean deleteJobApplication(Long id);
}
