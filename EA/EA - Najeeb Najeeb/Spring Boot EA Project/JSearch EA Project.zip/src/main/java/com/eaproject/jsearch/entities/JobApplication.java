package com.eaproject.jsearch.entities;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
public class JobApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private Integer resumeVersion;

    private LocalDateTime appliedDateTime;

    @ManyToOne
    private Job job;

    private boolean isOfferReceived;

}
