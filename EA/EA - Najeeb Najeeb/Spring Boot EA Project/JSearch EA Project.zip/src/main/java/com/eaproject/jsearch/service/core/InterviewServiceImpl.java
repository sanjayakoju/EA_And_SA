package com.eaproject.jsearch.service.core;

import com.eaproject.jsearch.entities.Interview;
import com.eaproject.jsearch.repository.InterviewRepository;
import com.eaproject.jsearch.service.InterviewService;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InterviewServiceImpl implements InterviewService {

    private final InterviewRepository interviewRepository;

    public InterviewServiceImpl(InterviewRepository interviewRepository) {
        this.interviewRepository = interviewRepository;
    }

    @Override
    public List<Interview> getAllInterviews() {
        return interviewRepository.findAll();
    }

    @Override
    public Interview getInterviewById(Long id) {
        return interviewRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Record not found for Interview Id: " + id));
    }

    @Override
    public Interview save(Interview interview) {
        return interviewRepository.save(interview);
    }

    @Override
    public Interview updateInterview(Interview interview) {
        Interview returnedInterview = getInterviewById(interview.getId());
        return interviewRepository.save(returnedInterview);
    }

    @Override
    public boolean deleteInterview(Long id) {
        Interview returnedInterview = getInterviewById(id);
        interviewRepository.deleteById(returnedInterview.getId());
        return true;
    }
}
