package com.eaproject.jsearch.entities;


import com.eaproject.jsearch.entities.company.Branch;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.enums.PositionLevel;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @OneToMany(mappedBy = "job", cascade = CascadeType.PERSIST)
    private List<Skill> skills;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Company company;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "branch_id")
    private Branch branch;

    @Enumerated(value = EnumType.STRING)
    private PositionLevel positionLevel;

    private LocalDateTime datePosted;

    private double selfRatingPercent;

    private boolean isRemote;

    private long salaryEstimateKPerYear;

    private double salaryEstimatePerHour;

    @Column(columnDefinition = "TEXT")
    private String fullDescription;

    private double minRequiredExpInYears;

    private boolean isDisabled;

}
