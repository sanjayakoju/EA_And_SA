//package com.eaproject.jsearch.config;
//
//import org.eclipse.persistence.config.BatchWriting;
//import org.eclipse.persistence.config.PersistenceUnitProperties;
//import org.eclipse.persistence.logging.SessionLog;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.orm.jpa.JpaTransactionManager;
//import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
//import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
//import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;
//import org.springframework.transaction.PlatformTransactionManager;
//
//import javax.persistence.EntityManagerFactory;
//import javax.sql.DataSource;
//import java.util.HashMap;
//import java.util.Map;
//
//@Configuration
////@EnableJpaRepositories(basePackages = "com.eaproject.jsearch.repository")
//public class JpaConfigurationBeanBasedConfig {
//
//    @Value("${spring.datasource.url:jdbc:h2:mem:testdb}")
//    private String dataSourceUrl;
//
//    @Value("${spring.datasource.url:sa}")
//    private String username;
//
//    @Value("${spring.datasource.password:password}")
//    private String password;
//
//    @Value("${spring.datasource.driverEntity-class-name:org.h2.Driver}")
//    private String driverClassName;
//
//    @Value("${app.jpa.databasePlatform:org.eclipse.persistence.platform.database.H2Platform}")
//    private String databasePlatform;
//
//    private boolean showSql = true;
//
//    @Bean
//    @Primary
//    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
//        LocalContainerEntityManagerFactoryBean emfBean = new LocalContainerEntityManagerFactoryBean();
//        emfBean.setDataSource(dataSource());
//        emfBean.setPackagesToScan("com.eaproject.jsearch.entities");
//        emfBean.setJpaVendorAdapter(createJpaVendorAdapter());
//        emfBean.setJpaPropertyMap(getVendorProperties());
//        return emfBean;
//    }
//
//    private AbstractJpaVendorAdapter createJpaVendorAdapter() {
//        EclipseLinkJpaVendorAdapter eclipseLinkJpaVendorAdapter = new EclipseLinkJpaVendorAdapter();
//        eclipseLinkJpaVendorAdapter.setShowSql(showSql);
////        eclipseLinkJpaVendorAdapter.setGenerateDdl(false);
//        eclipseLinkJpaVendorAdapter.setDatabasePlatform(databasePlatform);
//        return eclipseLinkJpaVendorAdapter;
//    }
//
//    private Map<String, Object> getVendorProperties() {
//
//        // Eclipse Link Vendor Properties
//        HashMap<String, Object> map = new HashMap<>();
//        String weavingMode = InstrumentationLoadTimeWeaver.isInstrumentationAvailable() ? "true" : "static";
//        map.put(PersistenceUnitProperties.BATCH_WRITING, BatchWriting.JDBC);
//        map.put(PersistenceUnitProperties.LOGGING_LEVEL, SessionLog.FINER_LABEL);
//        map.put(PersistenceUnitProperties.WEAVING, weavingMode);
//        map.put(PersistenceUnitProperties.DDL_GENERATION, PersistenceUnitProperties.DROP_AND_CREATE);
//        map.put(PersistenceUnitProperties.DDL_GENERATION_MODE, PersistenceUnitProperties.DDL_DATABASE_GENERATION);
//        return map;
//    }
//
//    @Bean
//    public DataSource dataSource() {
//        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
//        dataSource.setDriverClassName(driverClassName);
//        dataSource.setUrl(dataSourceUrl);
//        dataSource.setUsername(username);
//        dataSource.setPassword(password);
//        return dataSource;
//    }
//
//    @Bean
//    public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
//        final JpaTransactionManager transactionManager = new JpaTransactionManager();
//        transactionManager.setEntityManagerFactory(emf);
//        return transactionManager;
//    }
//
//}
