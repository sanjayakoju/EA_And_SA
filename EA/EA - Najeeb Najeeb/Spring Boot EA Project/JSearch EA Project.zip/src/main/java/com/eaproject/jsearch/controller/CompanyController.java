package com.eaproject.jsearch.controller;

import com.eaproject.jsearch.entities.company.Client;
import com.eaproject.jsearch.entities.company.Recruiter;
import com.eaproject.jsearch.service.CompanyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/companies")
@Slf4j
public class CompanyController {

    private final CompanyService companyService;

    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    @GetMapping
    public ResponseEntity<?> allCompanies() {
        return new ResponseEntity<>(companyService.getAllCompanies(), HttpStatus.OK);
    }

    @GetMapping("top5-By-maxJobList")
    public ResponseEntity<?> findTop5CompaniesByMaximumNumberOfJobList() {
        return new ResponseEntity<>(companyService.findTop5CompaniesByMaximumNumberOfJobList(), HttpStatus.OK);
    }

    @PostMapping("recruiter")
    public ResponseEntity<?> saveRecruiter(@Valid @RequestBody Recruiter recruiter) {
        return new ResponseEntity<>(companyService.save(recruiter), HttpStatus.OK);
    }

    @PostMapping("client")
    public ResponseEntity<?> saveClient(@Valid @RequestBody Client client) {
        return new ResponseEntity<>(companyService.save(client), HttpStatus.OK);
    }

    @PutMapping("recruiter")
    public ResponseEntity<?> updateRecruiter(@Valid @RequestBody Recruiter recruiter) {
        return new ResponseEntity<>(companyService.updateRecruiter(recruiter), HttpStatus.OK);
    }

    @PutMapping("client")
    public ResponseEntity<?> updateClient(@Valid @RequestBody Recruiter recruiter) {
        return new ResponseEntity<>(companyService.updateRecruiter(recruiter), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCompany(@PathVariable Long id) {
        return new ResponseEntity<>(companyService.deleteCompany(id), HttpStatus.OK);
    }
}
