package com.eaproject.jsearch.controller;

import com.eaproject.jsearch.entities.Job;
import com.eaproject.jsearch.service.JobService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/jobs")
@Slf4j
public class JobController {

    private final JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    @GetMapping
    public ResponseEntity<?> allJobs() {
        return new ResponseEntity<>(jobService.getAllJobs(), HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getJobById(@PathVariable Long id) {
        return new ResponseEntity<>(jobService.getJobById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> save(@Valid @RequestBody Job job) {
        return new ResponseEntity<>(jobService.save(job), HttpStatus.OK);
    }

    @PutMapping
    public ResponseEntity<?> updateJob(@Valid @RequestBody Job job) {
        return new ResponseEntity<>(jobService.updateJob(job), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteJob(@PathVariable Long id) {
        return new ResponseEntity<>(jobService.deleteJobApplication(id), HttpStatus.OK);
    }
}
