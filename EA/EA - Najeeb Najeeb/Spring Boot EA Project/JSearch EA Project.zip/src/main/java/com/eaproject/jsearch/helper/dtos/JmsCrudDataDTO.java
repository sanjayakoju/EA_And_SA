package com.eaproject.jsearch.helper.dtos;

import com.eaproject.jsearch.helper.dtos.enums.OperationActionType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JmsCrudDataDTO<T, U> {

    private String reqDataClassName;

    private OperationActionType operationActionType;

    private T requestData;

    private String resDataClassName;

    private U responseData;

    private String statusMessage;

}
