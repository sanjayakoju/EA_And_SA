package com.eaproject.jsearch.entities.company;

import com.eaproject.jsearch.entities.Address;
import lombok.*;

import javax.persistence.*;

@Entity
@Data
public class Branch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(value = AccessLevel.NONE)
    private Long id;

    @ManyToOne
    private Company company;

    @ManyToOne(cascade = CascadeType.PERSIST)
    private Address address;

    private int noOfEmployees;

    public Branch() {
    }

    public Branch(Company company, Address address, int noOfEmployees) {
        this.company = company;
        this.address = address;
        this.noOfEmployees = noOfEmployees;
    }
}
