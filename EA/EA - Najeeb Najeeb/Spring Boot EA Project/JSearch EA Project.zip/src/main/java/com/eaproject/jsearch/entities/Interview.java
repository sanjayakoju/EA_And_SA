package com.eaproject.jsearch.entities;

import com.eaproject.jsearch.entities.enums.InterviewLocation;
import com.eaproject.jsearch.entities.enums.InterviewType;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
public class Interview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private JobApplication jobApplication;

    private LocalDateTime interviewDateTime;

    @Enumerated(EnumType.STRING)
    private InterviewLocation interviewLocation = InterviewLocation.ONLINE;

    @Enumerated(EnumType.STRING)
    private InterviewType interviewType;

    private Double durationHours;

    @Column(columnDefinition = "TEXT")
    private String overallSummary;

    @Column(columnDefinition = "TEXT")
    private String questionsAsked;

    private double successProbabilityPercent;

    private boolean isPassed;

}
