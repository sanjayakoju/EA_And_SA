package com.eaproject.jsearch.service.core;

import com.eaproject.jsearch.entities.Job;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.JobRepository;
import com.eaproject.jsearch.service.JobService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;

    public JobServiceImpl(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Override
    public Job save(Job jobEntity) {
        return jobRepository.save(jobEntity);
    }

    @Override
    public List<Job> getActiveJobs() {
        return jobRepository.findAllByIsDisabledFalse();

    }

    @Override
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    @Override
    public Job getJobById(Long id) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Record not found for Job Id: " + id));
        return job;
    }

    @Override
    public Job updateJob(Job jobEntity) {
        Job job = getJobById(jobEntity.getId());
//        Job mergedJob = entityManager.merge(jobEntity);
        job.setTitle(jobEntity.getTitle());
        job.setSkills(jobEntity.getSkills());
        job.setFullDescription(jobEntity.getFullDescription());
        return jobRepository.save(job);
    }

    @Override
    public boolean deleteJobApplication(Long id) {
        Job returnedJob = getJobById(id);
        jobRepository.deleteById(returnedJob.getId());
        return true;
    }
}
