package com.eaproject.jsearch.service.core;

import com.eaproject.jsearch.entities.JobApplication;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.JobApplicationRepository;
import com.eaproject.jsearch.service.JobApplicationService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobApplicationServiceImpl implements JobApplicationService {

    private final JobApplicationRepository jobApplicationRepository;

    public JobApplicationServiceImpl(JobApplicationRepository jobApplicationRepository) {
        this.jobApplicationRepository = jobApplicationRepository;
    }

    @Override
    public List<JobApplication> getAllJobApplications() {
        return jobApplicationRepository.findAll();
    }

    @Override
    public JobApplication getJobApplicationById(Long id) {
        return jobApplicationRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Record not found for JobApplication Id: " + id));
    }

    @Override
    public JobApplication save(JobApplication jobApplication) {
        return jobApplicationRepository.save(jobApplication);
    }

    @Override
    public JobApplication updateJobApplication(JobApplication jobApplication) {
        JobApplication returnedJobApplication = getJobApplicationById(jobApplication.getId());
        return jobApplicationRepository.save(returnedJobApplication);
    }

    @Override
    public boolean deleteJobApplication(Long id) {
        JobApplication returnedJobApplication = getJobApplicationById(id);
        jobApplicationRepository.deleteById(returnedJobApplication.getId());
        return true;
    }
}
