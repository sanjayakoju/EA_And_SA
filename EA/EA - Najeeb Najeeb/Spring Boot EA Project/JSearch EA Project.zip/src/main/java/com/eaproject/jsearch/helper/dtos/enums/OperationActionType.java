package com.eaproject.jsearch.helper.dtos.enums;

public enum OperationActionType {

    CREATE, UPDATE, GET_ALL, GET_BY_ID, DELETE, RESPONSE_READ_ONLY
}
