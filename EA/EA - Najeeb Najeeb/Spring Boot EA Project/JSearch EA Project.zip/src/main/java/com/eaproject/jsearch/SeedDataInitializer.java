package com.eaproject.jsearch;

import com.eaproject.jsearch.entities.*;
import com.eaproject.jsearch.entities.company.Branch;
import com.eaproject.jsearch.entities.company.Client;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.company.Recruiter;
import com.eaproject.jsearch.entities.enums.InterviewType;
import com.eaproject.jsearch.entities.enums.PositionLevel;
import com.eaproject.jsearch.repository.CompanyRepository;
import com.eaproject.jsearch.repository.InterviewRepository;
import com.eaproject.jsearch.repository.JobApplicationRepository;
import com.eaproject.jsearch.repository.JobRepository;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class SeedDataInitializer implements CommandLineRunner {

    private final CompanyRepository companyRepository;
    private final JobRepository jobRepository;
    private final JobApplicationRepository jobApplicationRepository;
    private final InterviewRepository interviewRepository;

    @Value(value = "${app.load.seed-data: false}")
    private boolean loadSeedData;

    @Autowired
    public SeedDataInitializer(final CompanyRepository companyRepository, final JobRepository jobRepository, final JobApplicationRepository jobApplicationRepository, InterviewRepository interviewRepository) {
        this.companyRepository = companyRepository;
        this.jobRepository = jobRepository;
        this.jobApplicationRepository = jobApplicationRepository;
        this.interviewRepository = interviewRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (loadSeedData) {
            populateCompanies();
            populateJobs();
            initializeMockApplication();
        }
    }


    @Transactional
    public void populateCompanies() {
        // Clients
        Client google = new Client();
        google.setName("Google");
        google.setDescription("Google");
        Branch googleCABranch = new Branch(google, new Address("California", "Mountain View", 0), 0);
        google.setMainBranch(googleCABranch);
        companyRepository.save(google);

        Client microsoft = new Client();
        microsoft.setName("Microsoft");
        microsoft.setDescription("Microsoft");
        Branch microsoftWABranch = new Branch(microsoft, new Address("Washington", "Redmond", 0), 0);
        microsoft.setMainBranch(microsoftWABranch);
        companyRepository.save(microsoft);

        // Recruiters
        Recruiter kForce = new Recruiter();
        kForce.setName("KForce");
        kForce.setHasPrevAlumni(true);
        Branch kForceFLBranch = new Branch(kForce, new Address("Florida", "Tampa", 0), 0);
        kForce.setMainBranch(kForceFLBranch);
        kForce.setClients(List.of(google, microsoft));
        companyRepository.save(kForce);

        Recruiter insightGlobal = new Recruiter();
        insightGlobal.setName("JP Morgan");
        insightGlobal.setHasPrevAlumni(true);
        Branch insightGABranch = new Branch(insightGlobal, new Address("Georgia State", "Atlanta", 0), 0);
        insightGlobal.setMainBranch(insightGABranch);
        companyRepository.save(insightGlobal);
    }

    @Transactional
    public void populateJobs() {
        Job srSEngineer = new Job();
        srSEngineer.setTitle("Senior Software Engineer");
        srSEngineer.setFullDescription("Fully remote Senior Software Engineer to join their team");
        srSEngineer.setRemote(true);
        srSEngineer.setMinRequiredExpInYears(4.0);
        srSEngineer.setPositionLevel(PositionLevel.SENIOR);
        srSEngineer.setSalaryEstimateKPerYear(120);
        srSEngineer.setSelfRatingPercent(100);
        Company companyKForce = companyRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException());
        srSEngineer.setCompany(companyKForce);

        Branch kForceGABranch = new Branch(companyKForce, new Address("Georgia State", "Atlanta", 0), 0);
        srSEngineer.setBranch(kForceGABranch);
        srSEngineer.setSkills(List.of(
                new Skill("Frontend", 2.0, "", "JavaScript, Angular", srSEngineer),
                new Skill("Backend", 2.0, "", "Java, Spring", srSEngineer),
                new Skill("Knowledge", 2.0, "", "MySQL, Docker, AWS, GIT", srSEngineer),
                new Skill("Preferred", 4.0, "", "ELK Stack, Mongo DB, Postgres, Graph QL", srSEngineer)
        ));
        jobRepository.save(srSEngineer);

        Job fullStackDeveloper = new Job();
        fullStackDeveloper.setTitle("Full Stack Developer");
        fullStackDeveloper.setFullDescription("Full stack REST Api, Spring, Angular or React Developer");
        fullStackDeveloper.setRemote(false);
        fullStackDeveloper.setMinRequiredExpInYears(1);
        fullStackDeveloper.setPositionLevel(PositionLevel.MID);
        fullStackDeveloper.setSalaryEstimateKPerYear(100);
        fullStackDeveloper.setSelfRatingPercent(90);
        fullStackDeveloper.setCompany(companyKForce);

        Branch kForceFLBranch = new Branch(companyKForce, new Address("Florida", "Miramar", 0), 0);
        fullStackDeveloper.setBranch(kForceFLBranch);
        fullStackDeveloper.setSkills(List.of(
                new Skill("FullStack", 1.0, "", "Node/Spring/C++, JavaScript", fullStackDeveloper),
                new Skill("Preferred", 4.0, "", "REST Api, Web Development, GIT, Database", fullStackDeveloper)
        ));
        jobRepository.save(fullStackDeveloper);

        Job javaDeveloper = new Job();
        javaDeveloper.setTitle("Java Developer");
        javaDeveloper.setFullDescription("Motivated Java Developer with good programming knowledge. MySQL/Oracle");
        javaDeveloper.setRemote(false);
        javaDeveloper.setMinRequiredExpInYears(1);
        javaDeveloper.setPositionLevel(PositionLevel.ENTRY);
        javaDeveloper.setSalaryEstimateKPerYear(90);
        javaDeveloper.setSelfRatingPercent(80);
        Company companyInsight = companyRepository.findById(2L).orElseThrow(() -> new ResourceNotFoundException());
        javaDeveloper.setCompany(companyInsight);

        Branch aoFLBranch = new Branch(companyInsight, new Address("Florida", "Miramar", 0), 0);
        javaDeveloper.setBranch(aoFLBranch);
        fullStackDeveloper.setSkills(List.of(
                new Skill("FullStack", 1.0, "", "Spring, Hibernate, OAuth2", javaDeveloper),
                new Skill("Preferred", 4.0, "", "Microservices, AWS, TDD, REST Api, Docker", javaDeveloper)
        ));
        jobRepository.save(javaDeveloper);
    }

    @Transactional
    public void initializeMockApplication() {
        Job srSoftJob = jobRepository.findById(1L).orElseThrow(() -> new ResourceNotFoundException());

        JobApplication softEngApplication = new JobApplication();
        softEngApplication.setAppliedDateTime(LocalDateTime.now());
        softEngApplication.setJob(srSoftJob);
        jobApplicationRepository.save(softEngApplication);

        // Phase 1 : Passed Screening Interview
        Interview screeningInterview = new Interview();
        screeningInterview.setInterviewType(InterviewType.SCREENING_INTERVIEW);
        screeningInterview.setJobApplication(softEngApplication);
        screeningInterview.setInterviewDateTime(LocalDateTime.now().minusDays(5));
        screeningInterview.setDurationHours(0.5);
        screeningInterview.setOverallSummary("Worked on algorithm and programming question");
        screeningInterview.setSuccessProbabilityPercent(90);
        screeningInterview.setPassed(true);
        interviewRepository.save(screeningInterview);


        // Phase 2: Completed and Waiting Technical Interview 1 result
        Interview technicalInterview = new Interview();
        technicalInterview.setInterviewType(InterviewType.TECHNICAL_INTERVIEW);
        technicalInterview.setJobApplication(softEngApplication);
        technicalInterview.setInterviewDateTime(LocalDateTime.now().minusDays(1));
        technicalInterview.setDurationHours(1.5);
        technicalInterview.setOverallSummary("Was asked about Java, Spring, Hibernate, Testing, Microservices, SQL and some JavaScript");
        technicalInterview.setSuccessProbabilityPercent(70);
        interviewRepository.save(technicalInterview);

        // Phase 3: Scheduled Technical Interview 2
        Interview technicalInterview2 = new Interview();
        technicalInterview2.setInterviewType(InterviewType.SCREENING_INTERVIEW);
        technicalInterview2.setJobApplication(softEngApplication);
        technicalInterview2.setInterviewDateTime(LocalDateTime.now().plusDays(2));
        interviewRepository.save(technicalInterview2);
    }
}
