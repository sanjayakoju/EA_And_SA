package com.eaproject.jsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableAspectJAutoProxy
@EnableJms
public class JSearchEaProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(JSearchEaProjectApplication.class, args);
    }
}
