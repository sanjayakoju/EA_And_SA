package com.eaproject.jsearch.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Slf4j
@Component
public class AspectDeleteLogging {

    @Pointcut("execution(* com.eaproject.jsearch.service.core.CompanyServiceImpl.deleteCompany(..))")
    public void onCompanyDeleteCalled() {
    }

    @Pointcut("execution(* com.eaproject.jsearch.service.core.JobServiceImpl.deleteJobApplication(..))")
    public void onJobDeleteCalled() {
    }

    @Pointcut("execution(* com.eaproject.jsearch.service.core.JobApplicationServiceImpl.deleteJobApplication(..))")
    public void onDeleteJobApplicationCalled() {
    }

    @Pointcut("execution(* com.eaproject.jsearch.service.core.InterviewServiceImpl.deleteInterview(..))")
    public void onDeleteInterviewCalled() {
    }

    @After("onCompanyDeleteCalled() || onJobDeleteCalled() || onDeleteJobApplicationCalled() || onDeleteInterviewCalled()")
    public void afterDeleteTriggered(JoinPoint joinPoint) {
        log.info("Delete Method " + joinPoint.getSignature().getName() + "called successfully");
    }


}
