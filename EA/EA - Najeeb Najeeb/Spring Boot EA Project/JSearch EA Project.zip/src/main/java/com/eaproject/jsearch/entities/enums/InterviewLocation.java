package com.eaproject.jsearch.entities.enums;

public enum InterviewLocation {
    ONLINE, PHONE, IN_PERSON,
}
