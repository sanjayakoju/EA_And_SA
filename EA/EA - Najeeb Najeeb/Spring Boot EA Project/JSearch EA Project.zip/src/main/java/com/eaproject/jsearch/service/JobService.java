package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.Job;

import java.util.List;

public interface JobService {

    List<Job> getActiveJobs();

    List<Job> getAllJobs();

    Job getJobById(Long id);

    Job save(Job job);

    Job updateJob(Job job);

    boolean deleteJobApplication(Long id);
}
