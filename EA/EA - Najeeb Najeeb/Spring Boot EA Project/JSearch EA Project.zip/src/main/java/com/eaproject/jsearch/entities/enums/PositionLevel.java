package com.eaproject.jsearch.entities.enums;

public enum PositionLevel {

    ENTRY, MID, SENIOR, MANAGER, ARCHITECT
}
