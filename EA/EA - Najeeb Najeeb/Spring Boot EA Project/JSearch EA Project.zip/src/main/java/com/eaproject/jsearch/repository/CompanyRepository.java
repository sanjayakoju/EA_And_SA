package com.eaproject.jsearch.repository;

import com.eaproject.jsearch.entities.company.Client;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.company.Recruiter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Long> {

    @Query(value = "SELECT c FROM Company c WHERE (SELECT COUNT(j.company) FROM Job j WHERE j.company.id = c.id Group by j.company) > 1")
    List<Company> findTop5CompaniesByMaximumNumberOfJobList();

    @Query(value = "select r from Recruiter r")
    Optional<Recruiter> getRecruiterById(Long id);

    @Query(value = "select c from Client c")
    Optional<Client> getClientById(Long id);
}
