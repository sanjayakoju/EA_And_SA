package com.eaproject.jsearch.controller;

import com.eaproject.jsearch.entities.JobApplication;
import com.eaproject.jsearch.helper.dtos.ResponseWrapperDTO;
import com.eaproject.jsearch.helper.dtos.enums.OperationActionType;
import com.eaproject.jsearch.service.jms.JmsCRUDManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/jms/job-applications")
@Slf4j
public class JobApplicationJmsAPI {

    private final JmsCRUDManager jmsCRUDManager;

    public JobApplicationJmsAPI(JmsCRUDManager jmsCRUDManager) {
        this.jmsCRUDManager = jmsCRUDManager;
    }

    @GetMapping
    public ResponseEntity<?> allJobApplications() {
        ResponseWrapperDTO responseWrapperDTO = jmsCRUDManager.sendCrudRequestForProcessing(new JobApplication(), OperationActionType.GET_ALL);
        return new ResponseEntity<>(responseWrapperDTO, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> getJobApplicationById(@PathVariable Long id) {
        JobApplication jobApplication = new JobApplication();
        jobApplication.setId(id);
        ResponseWrapperDTO responseWrapperDTO = jmsCRUDManager.sendCrudRequestForProcessing(jobApplication, OperationActionType.GET_BY_ID);
        return new ResponseEntity<>(responseWrapperDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> saveJobApplication(@Valid @RequestBody JobApplication jobApplication) {
        ResponseWrapperDTO responseWrapperDTO = jmsCRUDManager.sendCrudRequestForProcessing(jobApplication, OperationActionType.CREATE);
        return new ResponseEntity<>(responseWrapperDTO, HttpStatus.OK);
    }

    @PutMapping
    public ResponseEntity<?> updateJobApplication(@Valid @RequestBody JobApplication jobApplication) {
        ResponseWrapperDTO responseWrapperDTO = jmsCRUDManager.sendCrudRequestForProcessing(jobApplication, OperationActionType.UPDATE);
        return new ResponseEntity<>(responseWrapperDTO, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteJobApplication(@PathVariable Long id) {
        JobApplication jobApplication = new JobApplication();
        jobApplication.setId(id);
        ResponseWrapperDTO responseWrapperDTO = jmsCRUDManager.sendCrudRequestForProcessing(jobApplication, OperationActionType.DELETE);
        return new ResponseEntity<>(responseWrapperDTO, HttpStatus.OK);
    }
}
