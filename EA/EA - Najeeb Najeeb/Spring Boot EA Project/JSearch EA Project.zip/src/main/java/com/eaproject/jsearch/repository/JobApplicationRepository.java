package com.eaproject.jsearch.repository;

import com.eaproject.jsearch.entities.Address;
import com.eaproject.jsearch.entities.JobApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {

    @Query(value = "select j.branch.address from JobApplication ja inner join Job j on ja.job.id = j.id")
    List<Address> findAllAddressForCurrentlyAppliedJob();
}
