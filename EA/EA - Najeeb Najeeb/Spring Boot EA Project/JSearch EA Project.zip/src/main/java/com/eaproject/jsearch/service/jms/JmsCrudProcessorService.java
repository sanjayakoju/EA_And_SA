package com.eaproject.jsearch.service.jms;

import com.eaproject.jsearch.entities.JobApplication;
import com.eaproject.jsearch.helper.dtos.JmsCrudDataDTO;
import com.eaproject.jsearch.helper.dtos.enums.OperationActionType;
import com.eaproject.jsearch.service.JobApplicationService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

@Service
public class JmsCrudProcessorService {

    private final JobApplicationService jobApplicationService;
    private final JmsCRUDManager jmsCRUDManager;

    public JmsCrudProcessorService(JobApplicationService jobApplicationService, JmsCRUDManager jmsCRUDManager) {
        this.jobApplicationService = jobApplicationService;
        this.jmsCRUDManager = jmsCRUDManager;
    }

    @JmsListener(destination = "${app.jms.crud.operation.queue}")
    public void processJmsCrudRequest(JmsCrudDataDTO<?, ?> jmsCrudDataDTO) throws InvocationTargetException, IllegalAccessException, InstantiationException, NoSuchMethodException {

        if (jmsCrudDataDTO.getReqDataClassName().equals(JobApplication.class.getName())) {
            processForJobApplicationCRUDRequest(jmsCrudDataDTO);
        }

    }

    private void processForJobApplicationCRUDRequest(JmsCrudDataDTO<?, ?> jmsCrudDataDTO) throws IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException {
        JobApplication requestData = (JobApplication) BeanUtils.cloneBean(jmsCrudDataDTO.getRequestData());

        if (jmsCrudDataDTO.getOperationActionType().equals(OperationActionType.CREATE)) {
            JobApplication saved = jobApplicationService.save(requestData);
            jmsCRUDManager.createAndSendCrudDataResponse(requestData, saved);
        }
        if (jmsCrudDataDTO.getOperationActionType().equals(OperationActionType.UPDATE)) {
            JobApplication saved = jobApplicationService.updateJobApplication(requestData);
            jmsCRUDManager.createAndSendCrudDataResponse(requestData, saved);
        }
        if (jmsCrudDataDTO.getOperationActionType().equals(OperationActionType.DELETE)) {
            jobApplicationService.deleteJobApplication(requestData.getId());
            jmsCRUDManager.createAndSendCrudDataResponse(requestData, Boolean.TRUE);
        }
        if (jmsCrudDataDTO.getOperationActionType().equals(OperationActionType.GET_ALL)) {
            List<JobApplication> allJobApplications = jobApplicationService.getAllJobApplications();
            jmsCRUDManager.createAndSendCrudDataResponse(requestData, allJobApplications);
        }
        if (jmsCrudDataDTO.getOperationActionType().equals(OperationActionType.GET_BY_ID)) {
            JobApplication jobApplication = jobApplicationService.getJobApplicationById(requestData.getId());
            jmsCRUDManager.createAndSendCrudDataResponse(requestData, jobApplication);
        }

    }

}
