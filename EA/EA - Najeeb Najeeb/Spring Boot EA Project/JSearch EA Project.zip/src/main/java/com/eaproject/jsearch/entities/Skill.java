package com.eaproject.jsearch.entities;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Skill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private Double experience;

    private String description;

    private String language;

    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

    public Skill() {
    }

    public Skill(String name, Double experience, String description, String language, Job job) {
        this.name = name;
        this.experience = experience;
        this.description = description;
        this.language = language;
        this.job = job;
    }
}
