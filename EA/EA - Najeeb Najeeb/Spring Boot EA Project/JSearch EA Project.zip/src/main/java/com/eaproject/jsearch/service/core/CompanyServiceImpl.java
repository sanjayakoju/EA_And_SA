package com.eaproject.jsearch.service.core;

import com.eaproject.jsearch.entities.company.Client;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.company.Recruiter;
import com.eaproject.jsearch.helper.exceptions.ResourceNotFoundException;
import com.eaproject.jsearch.repository.CompanyRepository;
import com.eaproject.jsearch.service.CompanyService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyServiceImpl implements CompanyService {

    private final CompanyRepository companyRepository;

    public CompanyServiceImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public Company getById(Long id) {
        return companyRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Record not found for Company Id: " + id));
    }

    @Override
    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    @Override
    public List<Company> findTop5CompaniesByMaximumNumberOfJobList() {
        return companyRepository.findTop5CompaniesByMaximumNumberOfJobList();
    }

    @Override
    public Company save(Company company) {
        return companyRepository.save(company);
    }

    @Override
    public Recruiter saveRecruiter(Recruiter recruiter) {
        return companyRepository.save(recruiter);
    }

    @Override
    public Client saveClient(Client client) {
        return companyRepository.save(client);
    }

    @Override
    public Recruiter updateRecruiter(Recruiter recruiter) {
        Recruiter returnedRecruiter = companyRepository.getRecruiterById(recruiter.getId())
                .orElseThrow(() -> new ResourceNotFoundException());
        return companyRepository.save(returnedRecruiter);
    }

    @Override
    public Client updateClient(Client recruiter) {
        Client returnedClient = companyRepository.getClientById(recruiter.getId())
                .orElseThrow(() -> new ResourceNotFoundException());
        return companyRepository.save(returnedClient);
    }

    @Override
    public boolean deleteCompany(Long id) {
        Company returnedCompany = getById(id);
        companyRepository.deleteById(returnedCompany.getId());
        return true;
    }
}
