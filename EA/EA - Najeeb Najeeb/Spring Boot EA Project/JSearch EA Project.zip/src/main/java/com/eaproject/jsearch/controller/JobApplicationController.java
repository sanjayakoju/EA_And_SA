package com.eaproject.jsearch.controller;

import com.eaproject.jsearch.entities.JobApplication;
import com.eaproject.jsearch.helper.dtos.ResponseWrapperDTO;
import com.eaproject.jsearch.helper.dtos.enums.OperationActionType;
import com.eaproject.jsearch.service.JobApplicationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/job-applications")
@Slf4j
public class JobApplicationController {

    private final JobApplicationService jobApplicationService;

    public JobApplicationController(JobApplicationService jobApplicationService) {
        this.jobApplicationService = jobApplicationService;
    }

    @GetMapping
    public ResponseEntity<?> allJobApplications() {
        return new ResponseEntity<>(jobApplicationService.getAllJobApplications(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getJobApplicationById(@PathVariable Long id) {
        return new ResponseEntity<>(jobApplicationService.getJobApplicationById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> saveJobApplication(@Valid @RequestBody JobApplication jobApplication) {
        return new ResponseEntity<>(jobApplicationService.save(jobApplication), HttpStatus.OK);
    }

    @PutMapping
    public ResponseEntity<?> updateJobApplication(@Valid @RequestBody JobApplication jobApplication) {
        return new ResponseEntity<>(jobApplicationService.updateJobApplication(jobApplication), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteJobApplication(@PathVariable Long id) {
        return new ResponseEntity<>(jobApplicationService.deleteJobApplication(id), HttpStatus.OK);
    }
}