package com.eaproject.jsearch.helper.exceptions;

public class CustomAppException extends RuntimeException {

    public CustomAppException() {
    }

    public CustomAppException(String message) {
        super(message);
    }
}
