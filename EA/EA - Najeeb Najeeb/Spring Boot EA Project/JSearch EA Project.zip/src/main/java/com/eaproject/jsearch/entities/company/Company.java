package com.eaproject.jsearch.entities.company;

import com.eaproject.jsearch.entities.Job;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "company_type")
@Data
public abstract class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "company")
    private List<Job> jobList;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    private Branch mainBranch;

}
