package com.eaproject.jsearch.entities;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "address")
@Data
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(value = AccessLevel.NONE)
    private Long id;

    private String state;

    private String city;

    private int zip;

    public Address() {
    }

    public Address(String state, String city, int zip) {
        this.state = state;
        this.city = city;
        this.zip = zip;
    }
}
