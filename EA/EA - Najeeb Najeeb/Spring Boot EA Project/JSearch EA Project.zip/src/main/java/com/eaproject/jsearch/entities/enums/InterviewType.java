package com.eaproject.jsearch.entities.enums;

public enum InterviewType {

    SCREENING_INTERVIEW, TECHNICAL_INTERVIEW, HR_INTERVIEW
}
