package com.eaproject.jsearch.controller;

import com.eaproject.jsearch.entities.Interview;
import com.eaproject.jsearch.service.InterviewService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/interviews")
@Slf4j
public class InterviewController {

    private final InterviewService interviewService;

    public InterviewController(InterviewService interviewService) {
        this.interviewService = interviewService;
    }

    @GetMapping
    public ResponseEntity<?> allInterviews() {
        return new ResponseEntity<>(interviewService.getAllInterviews(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getInterviewById(@PathVariable Long id) {
        return new ResponseEntity<>(interviewService.getInterviewById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> saveInterview(@Valid @RequestBody Interview interview) {
        return new ResponseEntity<>(interviewService.save(interview), HttpStatus.OK);
    }

    @PutMapping
    public ResponseEntity<?> updateInterview(@Valid @RequestBody Interview interview) {
        return new ResponseEntity<>(interviewService.updateInterview(interview), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteInterview(@PathVariable Long id) {
        return new ResponseEntity<>(interviewService.deleteInterview(id), HttpStatus.OK);
    }
}
