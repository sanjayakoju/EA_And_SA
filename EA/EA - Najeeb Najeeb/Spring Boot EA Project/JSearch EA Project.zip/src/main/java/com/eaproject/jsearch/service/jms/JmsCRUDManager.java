package com.eaproject.jsearch.service.jms;

import com.eaproject.jsearch.helper.dtos.JmsCrudDataDTO;
import com.eaproject.jsearch.helper.dtos.ResponseWrapperDTO;
import com.eaproject.jsearch.helper.dtos.enums.OperationActionType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class JmsCRUDManager {

    @Value(value = "${app.jms.crud.operation.queue")
    private String crudOperationQueue;

    @Value(value = "${app.jms.crud.readonly.queue")
    private String crudReadOnlyQueue;

    private final JmsTemplate jmsTemplate;

    public JmsCRUDManager(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    public <T> ResponseWrapperDTO sendCrudRequestForProcessing(T t, OperationActionType operationActionType) {
        String reqDataClass = t.getClass().getName();
        JmsCrudDataDTO<T, ?> jmsCrudDataDTO = new JmsCrudDataDTO<>();
        jmsCrudDataDTO.setReqDataClassName(reqDataClass);
        jmsCrudDataDTO.setRequestData(t);
        jmsCrudDataDTO.setOperationActionType(operationActionType);

        jmsTemplate.convertAndSend(crudOperationQueue, jmsCrudDataDTO);
        ResponseWrapperDTO responseWrapperDTO = new ResponseWrapperDTO(reqDataClass + " Object sent for processing");
        return responseWrapperDTO;
    }

    public <D, R> void createAndSendCrudDataResponse(D requestData, R responseData) {
        JmsCrudDataDTO<D, R> jmsCrudDataDTO = new JmsCrudDataDTO<>();
        jmsCrudDataDTO.setReqDataClassName(requestData.getClass().getName());
        jmsCrudDataDTO.setRequestData(requestData);
        jmsCrudDataDTO.setResDataClassName(responseData.getClass().getName());
        jmsCrudDataDTO.setOperationActionType(OperationActionType.RESPONSE_READ_ONLY);
        jmsCrudDataDTO.setResponseData(responseData);

        jmsTemplate.convertAndSend(crudReadOnlyQueue, jmsCrudDataDTO);
    }
}
