package com.eaproject.jsearch.repository;

import com.eaproject.jsearch.entities.Interview;
import com.eaproject.jsearch.entities.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface InterviewRepository extends JpaRepository<Interview, Long> {

    // Interview list, waiting for result
    List<Interview> findInterviewsBySuccessProbabilityPercentGreaterThanAndIsPassedFalse(double successProbabilityPercent);

    // All interview by jobId in DateTime Descending Order
    List<Interview> findAllByJobApplication_Job_IdOrderByInterviewDateTimeDesc(Long jobId);

    // Job which interview are scheduled between this date
    @Query(value = "select i.jobApplication.job from Interview i where i.interviewDateTime between :startDateTime and :endDateTime")
    List<Job> findAllJobsByUpcomingScheduledInterviewBetweenDateTime(LocalDateTime startDateTime, LocalDateTime endDateTime);

}