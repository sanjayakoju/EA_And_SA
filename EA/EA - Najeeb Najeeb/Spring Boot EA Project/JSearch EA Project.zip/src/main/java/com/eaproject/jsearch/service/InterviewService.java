package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.Interview;

import java.util.List;

public interface InterviewService {

    List<Interview> getAllInterviews();

    Interview getInterviewById(Long id);

    Interview save(Interview interview);

    Interview updateInterview(Interview interview);

    boolean deleteInterview(Long id);
}
