//package com.eaproject.jsearch.entities.listeners;
//
//import lombok.extern.slf4j.Slf4j;
//import org.hibernate.event.spi.PostDeleteEvent;
//import org.hibernate.event.spi.PostDeleteEventListener;
//import org.hibernate.persister.entity.EntityPersister;
//
//@Slf4j
//public class EntityEventListener implements PostDeleteEventListener {
//
//    public static final EntityEventListener INSTANCE = new EntityEventListener();
//
//    @Override
//    public void onPostDelete(final PostDeleteEvent event) {
//
//        final Object entity = event.getEntity();
//        log.info("Deleted Entity " + entity);
//    }
//
//    @Override
//    public boolean requiresPostCommitHanding(EntityPersister persister) {
//        return false;
//    }
//}