package com.eaproject.jsearch.service;

import com.eaproject.jsearch.entities.company.Client;
import com.eaproject.jsearch.entities.company.Company;
import com.eaproject.jsearch.entities.company.Recruiter;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CompanyService {

    Company getById(Long id);

    List<Company> getAllCompanies();

    List<Company> findTop5CompaniesByMaximumNumberOfJobList();

    Company save(Company company);

    Recruiter saveRecruiter(Recruiter recruiter);
    Client saveClient(Client client);

    Recruiter updateRecruiter(Recruiter recruiter);

    Client updateClient(Client recruiter);

    boolean deleteCompany(Long id);

}
