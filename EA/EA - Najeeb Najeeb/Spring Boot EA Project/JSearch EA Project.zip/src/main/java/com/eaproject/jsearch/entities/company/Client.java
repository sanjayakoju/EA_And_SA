package com.eaproject.jsearch.entities.company;

import lombok.Data;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@Data
@DiscriminatorValue(value = "CLIENT")
public class Client extends Company {

    private String description;

    private String website;

}
